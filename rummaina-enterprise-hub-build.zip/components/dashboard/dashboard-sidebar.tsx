import Link from 'next/link'
import { Activity, BarChart3, Gauge, LogOut, Server, ShieldCheck, Workflow } from 'lucide-react'
import { RummainaLogo } from '@/components/brand/rummaina-logo'
import { SecurityBadge } from '@/components/brand/security-badge'

const nav = [
  { href: '#overview', label: 'Overview', icon: Gauge },
  { href: '#analytics', label: 'Analytics', icon: BarChart3 },
  { href: '#security', label: 'Security Health', icon: ShieldCheck },
  { href: '#servers', label: 'Server Health', icon: Server },
  { href: '#traffic', label: 'Load & Edge', icon: Activity },
  { href: '#workflows', label: 'Workflows', icon: Workflow },
]

export function DashboardSidebar() {
  return (
    <aside className="sticky top-0 hidden h-dvh w-64 shrink-0 flex-col border-r border-sidebar-border bg-sidebar backdrop-blur-xl lg:flex">
      <div className="flex h-16 items-center border-b border-sidebar-border px-5">
        <Link href="/" aria-label="Rummaina home">
          <RummainaLogo />
        </Link>
      </div>
      <nav aria-label="Console" className="flex-1 overflow-y-auto p-3">
        <ul className="flex flex-col gap-0.5">
          {nav.map(({ href, label, icon: Icon }) => (
            <li key={href}>
              <a
                href={href}
                className="flex items-center gap-3 rounded-lg px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
              >
                <Icon className="size-4" aria-hidden="true" />
                {label}
              </a>
            </li>
          ))}
        </ul>
      </nav>
      <div className="flex flex-col gap-3 border-t border-sidebar-border p-4">
        <SecurityBadge label="Session Verified" className="self-start" />
        <Link
          href="/login"
          className="flex items-center gap-2 rounded-lg px-2 py-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
        >
          <LogOut className="size-4" aria-hidden="true" /> Sign out
        </Link>
      </div>
    </aside>
  )
}
