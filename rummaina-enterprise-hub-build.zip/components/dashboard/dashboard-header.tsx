import Link from 'next/link'
import { RummainaLogo } from '@/components/brand/rummaina-logo'
import { EncryptionIndicator } from '@/components/brand/security-badge'
import { LiveClock } from './live-clock'

export function DashboardHeader() {
  return (
    <header className="sticky top-0 z-40 flex h-16 items-center justify-between gap-4 border-b border-border bg-background/60 px-4 backdrop-blur-xl md:px-6">
      <div className="flex items-center gap-4">
        <Link href="/" aria-label="Rummaina home" className="lg:hidden">
          <RummainaLogo compact />
        </Link>
        <div>
          <p className="font-mono text-[11px] tracking-[0.25em] text-primary uppercase">Rummaina Control Center</p>
          <h1 className="text-lg font-semibold tracking-tight">Global Operations</h1>
        </div>
      </div>
      <div className="flex items-center gap-4">
        <EncryptionIndicator className="hidden md:inline-flex" />
        <LiveClock />
        <span
          className="grid size-9 place-items-center rounded-full border border-primary/30 bg-primary/10 font-mono text-xs font-semibold text-primary"
          aria-label="Signed in as Admin"
        >
          AD
        </span>
      </div>
    </header>
  )
}
