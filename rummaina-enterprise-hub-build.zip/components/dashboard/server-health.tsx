'use client'

import { cn } from '@/lib/utils'
import { formatNumber, initialNodes, tickNodes, useTicker, type ServerNode } from '@/lib/simulation'
import { LiveDot, Panel } from './panel'

const statusStyles: Record<ServerNode['status'], { tone: 'success' | 'warning' | 'destructive'; text: string }> = {
  healthy: { tone: 'success', text: 'text-success' },
  degraded: { tone: 'warning', text: 'text-warning' },
  draining: { tone: 'destructive', text: 'text-destructive' },
}

export function ServerHealth() {
  const nodes = useTicker(initialNodes, tickNodes, 2000)
  const healthy = nodes.filter((n) => n.status === 'healthy').length

  return (
    <Panel
      title="Server health"
      description={`${healthy}/${nodes.length} nodes healthy · auto-scaling enabled`}
      className="overflow-hidden"
    >
      <div className="-mx-5 overflow-x-auto px-5">
        <table className="w-full min-w-[640px] text-sm">
          <caption className="sr-only">Edge node resource utilization</caption>
          <thead>
            <tr className="text-left text-xs text-muted-foreground">
              <th scope="col" className="pb-3 font-normal">Node</th>
              <th scope="col" className="pb-3 font-normal">Status</th>
              <th scope="col" className="pb-3 font-normal">CPU</th>
              <th scope="col" className="pb-3 font-normal">Memory</th>
              <th scope="col" className="pb-3 text-right font-normal">Connections</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {nodes.map((n) => {
              const s = statusStyles[n.status]
              return (
                <tr key={n.id}>
                  <td className="py-3">
                    <div className="font-mono text-xs">{n.id}</div>
                    <div className="text-xs text-muted-foreground">{n.region}</div>
                  </td>
                  <td className="py-3">
                    <span className={cn('inline-flex items-center gap-2 text-xs capitalize', s.text)}>
                      <LiveDot tone={s.tone} /> {n.status}
                    </span>
                  </td>
                  <td className="py-3">
                    <Meter value={n.cpu} label={`CPU ${n.cpu}%`} />
                  </td>
                  <td className="py-3">
                    <Meter value={n.memory} label={`Memory ${n.memory}%`} />
                  </td>
                  <td className="py-3 text-right font-mono text-xs tabular-nums">{formatNumber(n.connections)}</td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </Panel>
  )
}

function Meter({ value, label }: { value: number; label: string }) {
  const color = value > 85 ? 'bg-destructive' : value > 70 ? 'bg-warning' : 'bg-primary'
  return (
    <div className="flex items-center gap-2.5">
      <div
        className="h-1.5 w-24 overflow-hidden rounded-full bg-muted"
        role="meter"
        aria-valuenow={value}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-label={label}
      >
        <div className={cn('h-full rounded-full transition-[width] duration-700', color)} style={{ width: `${value}%` }} />
      </div>
      <span className="w-9 font-mono text-xs tabular-nums text-muted-foreground">{value}%</span>
    </div>
  )
}
