import { cn } from '@/lib/utils'

export function Panel({
  title,
  description,
  action,
  className,
  children,
}: {
  title: string
  description?: string
  action?: React.ReactNode
  className?: string
  children: React.ReactNode
}) {
  return (
    <section className={cn('glass flex flex-col rounded-2xl p-5', className)} aria-label={title}>
      <div className="mb-4 flex items-start justify-between gap-3">
        <div>
          <h2 className="font-medium">{title}</h2>
          {description && <p className="mt-0.5 text-sm text-muted-foreground">{description}</p>}
        </div>
        {action}
      </div>
      {children}
    </section>
  )
}

export function PanelSkeleton({ className }: { className?: string }) {
  return (
    <div className={cn('glass flex flex-col gap-4 rounded-2xl p-5', className)} aria-busy="true">
      <span className="sr-only">Loading panel</span>
      <div className="h-4 w-40 animate-pulse rounded bg-muted" />
      <div className="h-3 w-64 animate-pulse rounded bg-muted/70" />
      <div className="mt-2 flex-1 animate-pulse rounded-xl bg-muted/40" />
    </div>
  )
}

export function LiveDot({ tone = 'success' }: { tone?: 'success' | 'warning' | 'destructive' }) {
  const color = { success: 'bg-success', warning: 'bg-warning', destructive: 'bg-destructive' }[tone]
  return (
    <span className="relative flex size-2" aria-hidden="true">
      <span className={cn('absolute inline-flex size-full animate-ping rounded-full opacity-60', color)} />
      <span className={cn('relative inline-flex size-2 rounded-full', color)} />
    </span>
  )
}
