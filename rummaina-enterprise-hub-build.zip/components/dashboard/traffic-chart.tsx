'use client'

import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { formatCompact, initialTraffic, seeded, useTicker, type TrafficPoint } from '@/lib/simulation'
import { LiveDot, Panel } from './panel'

let counter = 24
const rand = seeded(7)

function nextPoint(prev: TrafficPoint[]): TrafficPoint[] {
  const i = counter++
  const point: TrafficPoint = {
    t: `${String(i % 24).padStart(2, '0')}:00`,
    requests: Math.round(18000 + Math.sin(i / 3) * 6000 + rand() * 3000),
    blocked: Math.round(300 + rand() * 450),
    latency: Math.round(38 + rand() * 22),
  }
  return [...prev.slice(1), point]
}

const axisProps = {
  stroke: 'var(--muted-foreground)',
  fontSize: 11,
  tickLine: false,
  axisLine: false,
} as const

export default function TrafficChart() {
  const data = useTicker(initialTraffic(), nextPoint, 2500)

  return (
    <Panel
      title="Traffic & threat analytics"
      description="Edge requests versus WAF-blocked requests, streaming"
      action={
        <span className="flex items-center gap-2 font-mono text-xs text-muted-foreground">
          <LiveDot /> LIVE
        </span>
      }
      className="min-h-96"
    >
      <div className="mb-3 flex gap-4 text-xs text-muted-foreground">
        <span className="flex items-center gap-1.5">
          <span className="size-2 rounded-full bg-chart-1" /> Requests
        </span>
        <span className="flex items-center gap-1.5">
          <span className="size-2 rounded-full bg-chart-4" /> Blocked
        </span>
      </div>
      <div className="h-72 w-full" role="img" aria-label="Area chart of requests and blocked threats over time">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 4, right: 4, left: -12, bottom: 0 }}>
            <defs>
              <linearGradient id="fillReq" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="var(--chart-1)" stopOpacity={0.4} />
                <stop offset="100%" stopColor="var(--chart-1)" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="fillBlk" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="var(--chart-4)" stopOpacity={0.45} />
                <stop offset="100%" stopColor="var(--chart-4)" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid stroke="var(--border)" vertical={false} />
            <XAxis dataKey="t" {...axisProps} interval={3} />
            <YAxis yAxisId="req" {...axisProps} tickFormatter={formatCompact} />
            <YAxis yAxisId="blk" orientation="right" hide />
            <Tooltip
              contentStyle={{
                background: 'var(--popover)',
                border: '1px solid var(--border)',
                borderRadius: 10,
                fontSize: 12,
              }}
              labelStyle={{ color: 'var(--muted-foreground)' }}
            />
            <Area
              yAxisId="req"
              type="monotone"
              dataKey="requests"
              name="Requests"
              stroke="var(--chart-1)"
              strokeWidth={2}
              fill="url(#fillReq)"
              isAnimationActive={false}
            />
            <Area
              yAxisId="blk"
              type="monotone"
              dataKey="blocked"
              name="Blocked"
              stroke="var(--chart-4)"
              strokeWidth={2}
              fill="url(#fillBlk)"
              isAnimationActive={false}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </Panel>
  )
}
