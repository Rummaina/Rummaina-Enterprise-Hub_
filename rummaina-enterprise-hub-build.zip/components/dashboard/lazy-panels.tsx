'use client'

import dynamic from 'next/dynamic'
import { PanelSkeleton } from './panel'

// Chart bundles (recharts) are split out and loaded client-side so the console shell paints immediately.
export const LazyTrafficChart = dynamic(() => import('./traffic-chart'), {
  ssr: false,
  loading: () => <PanelSkeleton className="min-h-96" />,
})

export const LazyRegionLatencyChart = dynamic(() => import('./region-latency-chart'), {
  ssr: false,
  loading: () => <PanelSkeleton className="min-h-96" />,
})
