'use client'

import { useState } from 'react'
import { Pause, Play, Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import { useTicker } from '@/lib/simulation'
import { LiveDot, Panel } from './panel'

type Level = 'INFO' | 'OK' | 'WARN' | 'SEC'
type LogLine = { id: number; time: string; level: Level; workflow: string; message: string }

const templates: { level: Level; workflow: string; message: string }[] = [
  { level: 'OK', workflow: 'key-rotation', message: 'Rotated 128 data-encryption keys via KMS envelope' },
  { level: 'INFO', workflow: 'deploy-pipeline', message: 'Canary at 10% · error budget nominal' },
  { level: 'SEC', workflow: 'waf-guard', message: 'Blocked SQLi payload on /api/accounts (param: id)' },
  { level: 'OK', workflow: 'backup-snapshot', message: 'Encrypted snapshot replicated to fra1, iad1' },
  { level: 'WARN', workflow: 'autoscaler', message: 'sin1 CPU > 70% · provisioning 2 replicas' },
  { level: 'SEC', workflow: 'mfa-enforcer', message: 'Step-up challenge issued for privileged role change' },
  { level: 'INFO', workflow: 'cache-warm', message: 'Pre-warmed 2,341 edge objects across 312 PoPs' },
  { level: 'OK', workflow: 'compliance-scan', message: 'CIS benchmark passed · 0 critical findings' },
  { level: 'SEC', workflow: 'csrf-shield', message: 'Rejected cross-origin POST · origin mismatch' },
  { level: 'INFO', workflow: 'session-audit', message: 'Revoked 14 idle sessions exceeding 12h TTL' },
]

const levelStyles: Record<Level, string> = {
  INFO: 'text-primary',
  OK: 'text-success',
  WARN: 'text-warning',
  SEC: 'text-destructive',
}

const seedLogs: LogLine[] = templates.slice(0, 5).map((t, i) => ({
  ...t,
  id: i,
  time: 'boot',
}))

let nextId = seedLogs.length

export function WorkflowLogs() {
  const [paused, setPaused] = useState(false)
  const [cleared, setCleared] = useState(0)

  const logs = useTicker<LogLine[]>(
    seedLogs,
    (prev) => {
      if (paused) return prev
      const t = templates[Math.floor(Math.random() * templates.length)]
      const line = { ...t, id: nextId++, time: new Date().toISOString().slice(11, 19) }
      return [line, ...prev].slice(0, 40)
    },
    1400,
  )

  const visible = logs.filter((l) => l.id >= cleared)

  return (
    <Panel
      title="Workflow automation logs"
      description="Streaming events from orchestrated jobs"
      action={
        <div className="flex items-center gap-1">
          <span className="mr-2 hidden items-center gap-2 font-mono text-xs text-muted-foreground sm:flex">
            <LiveDot tone={paused ? 'warning' : 'success'} /> {paused ? 'PAUSED' : 'STREAMING'}
          </span>
          <Button
            variant="ghost"
            size="icon-sm"
            onClick={() => setPaused((p) => !p)}
            aria-label={paused ? 'Resume log stream' : 'Pause log stream'}
          >
            {paused ? <Play aria-hidden="true" /> : <Pause aria-hidden="true" />}
          </Button>
          <Button variant="ghost" size="icon-sm" onClick={() => setCleared(nextId)} aria-label="Clear logs">
            <Trash2 aria-hidden="true" />
          </Button>
        </div>
      }
    >
      <ol
        className="h-80 overflow-y-auto rounded-xl border border-border bg-background/60 p-3 font-mono text-xs leading-relaxed"
        aria-label="Workflow log stream"
      >
        {visible.length === 0 && <li className="py-8 text-center text-muted-foreground">Waiting for events…</li>}
        {visible.map((l) => (
          <li
            key={l.id}
            className="grid grid-cols-[4.5rem_3rem_1fr] gap-2 py-0.5 animate-in fade-in slide-in-from-top-1 sm:grid-cols-[4.5rem_3rem_9rem_1fr]"
          >
            <span className="text-muted-foreground">{l.time}</span>
            <span className={cn('font-semibold', levelStyles[l.level])}>{l.level}</span>
            <span className="hidden truncate text-foreground/80 sm:block">{l.workflow}</span>
            <span className="text-muted-foreground">{l.message}</span>
          </li>
        ))}
      </ol>
    </Panel>
  )
}
