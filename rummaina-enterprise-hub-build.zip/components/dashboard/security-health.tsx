'use client'

import { CheckCircle2, AlertTriangle } from 'lucide-react'
import { SecurityBadge } from '@/components/brand/security-badge'
import { cn } from '@/lib/utils'
import { drift, useTicker } from '@/lib/simulation'
import { Panel } from './panel'

type Control = { name: string; detail: string; ok: boolean }

const controls: Control[] = [
  { name: 'TLS 1.3 enforced', detail: 'HSTS · 2y max-age', ok: true },
  { name: 'Data at rest encrypted', detail: 'AES-256-GCM · KMS rotation 90d', ok: true },
  { name: 'Content-Security-Policy', detail: 'Report-only → enforce', ok: false },
  { name: 'CSRF protection', detail: 'SameSite + origin check', ok: true },
  { name: 'SQL injection guard', detail: 'Parameterized queries only', ok: true },
  { name: 'XSS sanitization', detail: 'Escaped output · nosniff', ok: true },
]

export function SecurityHealth() {
  const live = useTicker(
    { score: 96, mfa: 100, anomalies: 3 },
    (p) => ({
      score: Math.round(drift(p.score, 2, 92, 99)),
      mfa: 100,
      anomalies: Math.max(0, Math.round(drift(p.anomalies, 2, 0, 8))),
    }),
    2200,
  )

  return (
    <Panel
      title="Security health"
      description="Zero-trust posture, continuously evaluated"
      action={<SecurityBadge label="Shield Active" />}
    >
      <div className="grid grid-cols-3 gap-3">
        <Stat label="Posture score" value={`${live.score}`} tone="text-success" />
        <Stat label="MFA coverage" value={`${live.mfa}%`} tone="text-primary" />
        <Stat
          label="Open anomalies"
          value={`${live.anomalies}`}
          tone={live.anomalies > 4 ? 'text-destructive' : 'text-warning'}
        />
      </div>
      <div className="mt-4 h-2 overflow-hidden rounded-full bg-muted" aria-hidden="true">
        <div
          className="h-full rounded-full bg-gradient-to-r from-primary to-success transition-[width] duration-700"
          style={{ width: `${live.score}%` }}
        />
      </div>
      <ul className="mt-5 flex flex-col divide-y divide-border">
        {controls.map((c) => (
          <li key={c.name} className="flex items-center justify-between gap-3 py-2.5">
            <div className="flex items-center gap-2.5">
              {c.ok ? (
                <CheckCircle2 className="size-4 text-success" aria-hidden="true" />
              ) : (
                <AlertTriangle className="size-4 text-warning" aria-hidden="true" />
              )}
              <span className="text-sm">{c.name}</span>
            </div>
            <span className={cn('font-mono text-xs', c.ok ? 'text-muted-foreground' : 'text-warning')}>
              {c.detail}
            </span>
          </li>
        ))}
      </ul>
    </Panel>
  )
}

function Stat({ label, value, tone }: { label: string; value: string; tone: string }) {
  return (
    <div className="rounded-xl border border-border bg-background/40 p-3">
      <div className={cn('font-mono text-2xl font-semibold tabular-nums', tone)}>{value}</div>
      <div className="mt-0.5 text-xs text-muted-foreground">{label}</div>
    </div>
  )
}
