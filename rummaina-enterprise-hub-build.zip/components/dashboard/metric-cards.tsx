'use client'

import { Activity, Clock, ShieldX, Users } from 'lucide-react'
import { drift, formatCompact, formatNumber, useTicker } from '@/lib/simulation'

export function MetricCards() {
  const m = useTicker(
    { rps: 24812, p95: 142, blocked: 18204, sessions: 8431 },
    (p) => ({
      rps: Math.round(drift(p.rps, 2200, 16000, 34000)),
      p95: Math.round(drift(p.p95, 14, 96, 210)),
      blocked: p.blocked + Math.floor(Math.random() * 9),
      sessions: Math.round(drift(p.sessions, 120, 7000, 9800)),
    }),
    1500,
  )

  const cards = [
    { label: 'Requests / sec', value: formatNumber(m.rps), delta: '+4.2%', icon: Activity, tone: 'text-primary' },
    { label: 'Latency p95', value: `${m.p95}ms`, delta: 'SLO 250ms', icon: Clock, tone: 'text-warning' },
    { label: 'Threats blocked (24h)', value: formatCompact(m.blocked), delta: 'WAF + bot', icon: ShieldX, tone: 'text-destructive' },
    { label: 'Verified sessions', value: formatNumber(m.sessions), delta: '100% MFA', icon: Users, tone: 'text-success' },
  ]

  return (
    <ul id="overview" className="grid scroll-mt-20 gap-4 sm:grid-cols-2 xl:grid-cols-4">
      {cards.map(({ label, value, delta, icon: Icon, tone }) => (
        <li key={label} className="glass glass-hover rounded-2xl p-5">
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">{label}</span>
            <Icon className={`size-4 ${tone}`} aria-hidden="true" />
          </div>
          <div className="mt-3 font-mono text-3xl font-semibold tracking-tight tabular-nums">{value}</div>
          <div className="mt-1 font-mono text-xs text-muted-foreground">{delta}</div>
        </li>
      ))}
    </ul>
  )
}
