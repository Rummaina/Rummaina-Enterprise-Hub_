'use client'

import { Bar, BarChart, CartesianGrid, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { drift, useTicker } from '@/lib/simulation'
import { Panel } from './panel'

const initial = [
  { region: 'iad1', ms: 38 },
  { region: 'sfo1', ms: 44 },
  { region: 'fra1', ms: 52 },
  { region: 'sin1', ms: 88 },
  { region: 'gru1', ms: 61 },
  { region: 'syd1', ms: 73 },
]

const toneFor = (ms: number) => (ms > 85 ? 'var(--chart-4)' : ms > 65 ? 'var(--chart-3)' : 'var(--chart-2)')

export default function RegionLatencyChart() {
  const data = useTicker(
    initial,
    (prev) => prev.map((d) => ({ ...d, ms: Math.round(drift(d.ms, 10, 20, 110)) })),
    3000,
  )

  return (
    <Panel title="Edge latency by region" description="TTFB median, milliseconds" className="min-h-96">
      <div className="h-72 w-full" role="img" aria-label="Bar chart of median latency per edge region">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
            <CartesianGrid stroke="var(--border)" vertical={false} />
            <XAxis dataKey="region" stroke="var(--muted-foreground)" fontSize={11} tickLine={false} axisLine={false} />
            <YAxis stroke="var(--muted-foreground)" fontSize={11} tickLine={false} axisLine={false} />
            <Tooltip
              cursor={{ fill: 'oklch(1 0 0 / 4%)' }}
              contentStyle={{
                background: 'var(--popover)',
                border: '1px solid var(--border)',
                borderRadius: 10,
                fontSize: 12,
              }}
              formatter={(v) => [`${v}ms`, 'Latency']}
            />
            <Bar dataKey="ms" radius={[6, 6, 0, 0]} isAnimationActive={false}>
              {data.map((d) => (
                <Cell key={d.region} fill={toneFor(d.ms)} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </Panel>
  )
}
