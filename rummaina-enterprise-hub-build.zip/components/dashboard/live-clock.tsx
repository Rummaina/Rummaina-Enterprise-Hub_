'use client'

import { useTicker } from '@/lib/simulation'

export function LiveClock() {
  const now = useTicker<Date | null>(null, () => new Date(), 1000)
  return (
    <span className="hidden font-mono text-xs text-muted-foreground tabular-nums sm:inline" suppressHydrationWarning>
      {now ? `${now.toISOString().slice(11, 19)} UTC` : '--:--:-- UTC'}
    </span>
  )
}
