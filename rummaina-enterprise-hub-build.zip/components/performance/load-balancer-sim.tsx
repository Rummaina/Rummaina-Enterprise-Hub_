'use client'

import { useState } from 'react'
import { Globe, Server, Power } from 'lucide-react'
import { cn } from '@/lib/utils'
import { useTicker } from '@/lib/simulation'

type Backend = { id: string; label: string; online: boolean; weight: number }

const initialBackends: Backend[] = [
  { id: 'a', label: 'pool-a · iad1', online: true, weight: 34 },
  { id: 'b', label: 'pool-b · fra1', online: true, weight: 33 },
  { id: 'c', label: 'pool-c · sin1', online: true, weight: 33 },
]

export function LoadBalancerSim() {
  const [backends, setBackends] = useState(initialBackends)
  const uptime = useTicker(99.982, (u) => Math.min(99.999, +(u + 0.0003).toFixed(4)), 2000)

  const online = backends.filter((b) => b.online)
  const share = online.length ? Math.round(100 / online.length) : 0

  const toggle = (id: string) =>
    setBackends((prev) => {
      const target = prev.find((b) => b.id === id)
      if (target?.online && prev.filter((b) => b.online).length === 1) return prev
      return prev.map((b) => (b.id === id ? { ...b, online: !b.online } : b))
    })

  return (
    <div className="glass rounded-2xl p-5 md:p-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="font-medium">Global load balancer</h3>
          <p className="text-sm text-muted-foreground">Toggle a pool to watch traffic fail over instantly.</p>
        </div>
        <div className="text-right">
          <div className="font-mono text-2xl font-semibold tabular-nums text-success">{uptime.toFixed(3)}%</div>
          <div className="text-xs text-muted-foreground">Rolling 30-day uptime</div>
        </div>
      </div>

      <div className="mt-6 grid grid-cols-[auto_1fr] items-center gap-4 md:gap-6">
        <div className="flex flex-col items-center gap-2">
          <span className="grid size-14 place-items-center rounded-xl border border-primary/30 bg-primary/10 text-primary">
            <Globe className="size-6" aria-hidden="true" />
          </span>
          <span className="font-mono text-[11px] text-muted-foreground">anycast</span>
        </div>

        <ul className="flex flex-col gap-3">
          {backends.map((b, i) => (
            <li key={b.id} className="grid grid-cols-[1fr_auto] items-center gap-3">
              <div className="relative h-1.5 overflow-hidden rounded-full bg-muted" aria-hidden="true">
                {b.online &&
                  [0, 1, 2].map((p) => (
                    <span
                      key={p}
                      className="absolute top-0 left-0 h-full w-6 rounded-full bg-primary"
                      style={{
                        animation: `packet 1.6s linear ${p * 0.53 + i * 0.2}s infinite`,
                        ['--travel' as string]: '1200%',
                      }}
                    />
                  ))}
              </div>
              <button
                type="button"
                onClick={() => toggle(b.id)}
                aria-pressed={b.online}
                className={cn(
                  'flex w-44 items-center gap-2.5 rounded-lg border px-3 py-2 text-left text-sm transition-colors focus-visible:ring-3 focus-visible:ring-ring/50 focus-visible:outline-none',
                  b.online
                    ? 'border-success/30 bg-success/10 hover:bg-success/15'
                    : 'border-destructive/30 bg-destructive/10 hover:bg-destructive/15',
                )}
              >
                <Server className={cn('size-4', b.online ? 'text-success' : 'text-destructive')} aria-hidden="true" />
                <span className="flex-1">
                  <span className="block font-mono text-xs">{b.label}</span>
                  <span className="block text-[11px] text-muted-foreground">
                    {b.online ? `${share}% traffic` : 'offline · drained'}
                  </span>
                </span>
                <Power className="size-3.5 text-muted-foreground" aria-hidden="true" />
                <span className="sr-only">{b.online ? 'Take offline' : 'Bring online'}</span>
              </button>
            </li>
          ))}
        </ul>
      </div>
      <p className="mt-5 font-mono text-xs text-muted-foreground" aria-live="polite">
        {online.length}/{backends.length} pools healthy · health checks every 5s · failover {'<'} 300ms
      </p>
    </div>
  )
}
