'use client'

import { useState } from 'react'
import { Zap, RotateCcw } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

type Result = { path: string; status: 'HIT' | 'MISS' | 'STALE'; ms: number; region: string }

const paths = ['/api/accounts', '/dashboard', '/api/metrics', '/assets/app.js']
const regions = ['iad1', 'fra1', 'sin1', 'sfo1']

export function EdgeCacheSim() {
  const [warm, setWarm] = useState<Set<string>>(new Set())
  const [log, setLog] = useState<Result[]>([])

  const request = (path: string) => {
    const isHit = warm.has(path)
    const status: Result['status'] = isHit ? (Math.random() < 0.12 ? 'STALE' : 'HIT') : 'MISS'
    const ms = status === 'MISS' ? 140 + Math.round(Math.random() * 90) : 4 + Math.round(Math.random() * 14)
    const region = regions[Math.floor(Math.random() * regions.length)]
    setWarm((prev) => new Set(prev).add(path))
    setLog((prev) => [{ path, status, ms, region }, ...prev].slice(0, 6))
  }

  const purge = () => {
    setWarm(new Set())
    setLog([])
  }

  const hits = log.filter((l) => l.status !== 'MISS').length
  const ratio = log.length ? Math.round((hits / log.length) * 100) : 0

  return (
    <div className="glass flex flex-col rounded-2xl p-5 md:p-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="font-medium">Edge cache</h3>
          <p className="text-sm text-muted-foreground">Request a route twice to see it served from the edge.</p>
        </div>
        <div className="text-right">
          <div className="font-mono text-2xl font-semibold tabular-nums text-primary">{ratio}%</div>
          <div className="text-xs text-muted-foreground">Hit ratio</div>
        </div>
      </div>

      <div className="mt-5 flex flex-wrap gap-2">
        {paths.map((p) => (
          <Button key={p} variant="outline" size="sm" onClick={() => request(p)} className="font-mono">
            <Zap data-icon="inline-start" aria-hidden="true" />
            {p}
          </Button>
        ))}
        <Button variant="ghost" size="sm" onClick={purge}>
          <RotateCcw data-icon="inline-start" aria-hidden="true" />
          Purge
        </Button>
      </div>

      <ol className="mt-4 flex min-h-48 flex-col gap-1.5 font-mono text-xs" aria-live="polite">
        {log.length === 0 && <li className="py-6 text-center text-muted-foreground">No requests yet — edge is cold.</li>}
        {log.map((r, i) => (
          <li
            key={`${r.path}-${log.length - i}`}
            className="grid grid-cols-[3.5rem_1fr_auto_auto] items-center gap-3 rounded-md border border-border bg-background/40 px-3 py-2 animate-in fade-in slide-in-from-top-1"
          >
            <span
              className={cn(
                'rounded px-1.5 py-0.5 text-center font-semibold',
                r.status === 'HIT' && 'bg-success/15 text-success',
                r.status === 'STALE' && 'bg-warning/15 text-warning',
                r.status === 'MISS' && 'bg-destructive/15 text-destructive',
              )}
            >
              {r.status}
            </span>
            <span className="truncate">{r.path}</span>
            <span className="text-muted-foreground">{r.region}</span>
            <span className="w-12 text-right tabular-nums">{r.ms}ms</span>
          </li>
        ))}
      </ol>
    </div>
  )
}
