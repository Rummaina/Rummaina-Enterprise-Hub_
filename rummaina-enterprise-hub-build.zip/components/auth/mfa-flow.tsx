'use client'

import { useRef, useState, type FormEvent, type KeyboardEvent, type ClipboardEvent } from 'react'
import { useRouter } from 'next/navigation'
import { ArrowRight, CheckCircle2, KeyRound, Loader2, Lock, Mail, Smartphone } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { SecurityBadge, EncryptionIndicator } from '@/components/brand/security-badge'
import { cn } from '@/lib/utils'

type Step = 'credentials' | 'challenge' | 'verified'

const DEMO_CODE = '246810'
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

const steps: { id: Step; label: string }[] = [
  { id: 'credentials', label: 'Identity' },
  { id: 'challenge', label: 'Second factor' },
  { id: 'verified', label: 'Session issued' },
]

export function MfaFlow() {
  const router = useRouter()
  const [step, setStep] = useState<Step>('credentials')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [digits, setDigits] = useState<string[]>(Array(6).fill(''))
  const [error, setError] = useState<string | null>(null)
  const [pending, setPending] = useState(false)
  const inputs = useRef<(HTMLInputElement | null)[]>([])

  const wait = (ms: number) => new Promise((r) => setTimeout(r, ms))

  const submitCredentials = async (e: FormEvent) => {
    e.preventDefault()
    setError(null)
    if (!EMAIL_RE.test(email.trim())) return setError('Enter a valid work email address.')
    if (password.length < 12) return setError('Passwords must be at least 12 characters.')
    setPending(true)
    await wait(700)
    setPending(false)
    setStep('challenge')
    requestAnimationFrame(() => inputs.current[0]?.focus())
  }

  const submitCode = async (code: string) => {
    setError(null)
    setPending(true)
    await wait(600)
    setPending(false)
    if (code !== DEMO_CODE) {
      setDigits(Array(6).fill(''))
      inputs.current[0]?.focus()
      return setError('Invalid or expired code. Try again.')
    }
    setStep('verified')
    await wait(1200)
    router.push('/dashboard')
  }

  const setDigit = (i: number, value: string) => {
    const v = value.replace(/\D/g, '').slice(-1)
    const next = [...digits]
    next[i] = v
    setDigits(next)
    if (v && i < 5) inputs.current[i + 1]?.focus()
    if (next.every(Boolean)) submitCode(next.join(''))
  }

  const onKeyDown = (i: number, e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !digits[i] && i > 0) inputs.current[i - 1]?.focus()
  }

  const onPaste = (e: ClipboardEvent<HTMLInputElement>) => {
    const pasted = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 6)
    if (!pasted) return
    e.preventDefault()
    const next = Array.from({ length: 6 }, (_, i) => pasted[i] ?? '')
    setDigits(next)
    inputs.current[Math.min(pasted.length, 5)]?.focus()
    if (pasted.length === 6) submitCode(pasted)
  }

  const currentIndex = steps.findIndex((s) => s.id === step)

  return (
    <div className="glass w-full max-w-md rounded-2xl p-6 md:p-8">
      <SecurityBadge label="Zero-Trust Sign-in" />

      <ol className="mt-6 grid grid-cols-3 gap-2" aria-label="Sign-in progress">
        {steps.map((s, i) => (
          <li key={s.id} className="flex flex-col gap-2">
            <span
              className={cn(
                'h-1 rounded-full transition-colors duration-500',
                i <= currentIndex ? 'bg-primary' : 'bg-muted',
              )}
            />
            <span
              className={cn('text-xs', i === currentIndex ? 'text-foreground' : 'text-muted-foreground')}
              aria-current={i === currentIndex ? 'step' : undefined}
            >
              {s.label}
            </span>
          </li>
        ))}
      </ol>

      {step === 'credentials' && (
        <form onSubmit={submitCredentials} className="mt-8 flex flex-col gap-5" noValidate>
          <div>
            <h1 className="text-2xl font-semibold tracking-tight">Sign in to Rummaina</h1>
            <p className="mt-1 text-sm text-muted-foreground">Every session is verified. No exceptions.</p>
          </div>
          <Field id="email" label="Work email" icon={Mail}>
            <input
              id="email"
              type="email"
              autoComplete="username"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@company.com"
              className="w-full bg-transparent py-2.5 text-sm outline-none placeholder:text-muted-foreground"
            />
          </Field>
          <Field id="password" label="Password" icon={Lock}>
            <input
              id="password"
              type="password"
              autoComplete="current-password"
              required
              minLength={12}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Minimum 12 characters"
              className="w-full bg-transparent py-2.5 text-sm outline-none placeholder:text-muted-foreground"
            />
          </Field>
          <ErrorText error={error} />
          <Button type="submit" size="lg" className="h-11" disabled={pending}>
            {pending ? <Loader2 className="animate-spin" aria-hidden="true" /> : <KeyRound aria-hidden="true" />}
            {pending ? 'Verifying identity…' : 'Continue'}
          </Button>
        </form>
      )}

      {step === 'challenge' && (
        <form
          onSubmit={(e) => {
            e.preventDefault()
            submitCode(digits.join(''))
          }}
          className="mt-8 flex flex-col gap-5"
        >
          <div>
            <h1 className="text-2xl font-semibold tracking-tight">Verify it&apos;s you</h1>
            <p className="mt-1 flex items-center gap-2 text-sm text-muted-foreground">
              <Smartphone className="size-4" aria-hidden="true" /> Enter the 6-digit code from your authenticator.
            </p>
          </div>
          <fieldset>
            <legend className="sr-only">One-time passcode</legend>
            <div className="flex justify-between gap-2">
              {digits.map((d, i) => (
                <input
                  key={i}
                  ref={(el) => {
                    inputs.current[i] = el
                  }}
                  inputMode="numeric"
                  autoComplete={i === 0 ? 'one-time-code' : 'off'}
                  maxLength={1}
                  value={d}
                  disabled={pending}
                  onChange={(e) => setDigit(i, e.target.value)}
                  onKeyDown={(e) => onKeyDown(i, e)}
                  onPaste={onPaste}
                  aria-label={`Digit ${i + 1}`}
                  className="size-12 rounded-lg border border-input bg-background/50 text-center font-mono text-xl outline-none transition-colors focus:border-primary focus:ring-3 focus:ring-ring/40 disabled:opacity-60"
                />
              ))}
            </div>
          </fieldset>
          <ErrorText error={error} />
          <p className="rounded-lg border border-primary/20 bg-primary/5 px-3 py-2 font-mono text-xs text-muted-foreground">
            Demo environment · use code <span className="text-primary">{DEMO_CODE}</span>
          </p>
          <Button type="submit" size="lg" className="h-11" disabled={pending || digits.some((d) => !d)}>
            {pending ? <Loader2 className="animate-spin" aria-hidden="true" /> : <ArrowRight aria-hidden="true" />}
            {pending ? 'Checking code…' : 'Verify'}
          </Button>
        </form>
      )}

      {step === 'verified' && (
        <div className="mt-10 flex flex-col items-center gap-3 py-6 text-center" role="status">
          <CheckCircle2 className="size-14 text-success animate-in zoom-in" aria-hidden="true" />
          <h1 className="text-2xl font-semibold tracking-tight">Identity confirmed</h1>
          <p className="text-sm text-muted-foreground">Issuing a device-bound session. Redirecting to the console…</p>
        </div>
      )}

      <div className="mt-8 border-t border-border pt-4">
        <EncryptionIndicator />
      </div>
    </div>
  )
}

function Field({
  id,
  label,
  icon: Icon,
  children,
}: {
  id: string
  label: string
  icon: typeof Mail
  children: React.ReactNode
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={id} className="text-sm font-medium">
        {label}
      </label>
      <div className="flex items-center gap-2.5 rounded-lg border border-input bg-background/50 px-3 transition-colors focus-within:border-primary focus-within:ring-3 focus-within:ring-ring/40">
        <Icon className="size-4 text-muted-foreground" aria-hidden="true" />
        {children}
      </div>
    </div>
  )
}

function ErrorText({ error }: { error: string | null }) {
  return (
    <p role="alert" className={cn('min-h-5 text-sm text-destructive', !error && 'invisible')}>
      {error ?? ' '}
    </p>
  )
}
