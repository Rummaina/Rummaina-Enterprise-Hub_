import { cn } from '@/lib/utils'

export function RummainaMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" aria-hidden="true" className={cn('size-8', className)}>
      <defs>
        <linearGradient id="rmn-g" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="var(--primary)" />
          <stop offset="100%" stopColor="var(--success)" />
        </linearGradient>
      </defs>
      <path
        d="M16 2 28 8v8c0 7-5 12.5-12 14C9 28.5 4 23 4 16V8l12-6Z"
        fill="none"
        stroke="url(#rmn-g)"
        strokeWidth="2"
        strokeLinejoin="round"
      />
      <path
        d="M12 22V10h5a3.5 3.5 0 0 1 0 7h-5m5 0 4 5"
        fill="none"
        stroke="var(--foreground)"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

export function RummainaLogo({ className, compact = false }: { className?: string; compact?: boolean }) {
  return (
    <span className={cn('inline-flex items-center gap-2.5', className)}>
      <RummainaMark />
      {!compact && (
        <span className="flex flex-col leading-none">
          <span className="text-base font-semibold tracking-[0.18em] uppercase">Rummaina</span>
          <span className="mt-1 font-mono text-[10px] tracking-widest text-muted-foreground uppercase">
            Enterprise Hub
          </span>
        </span>
      )}
    </span>
  )
}
