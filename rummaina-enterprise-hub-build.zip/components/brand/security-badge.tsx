import { ShieldCheck } from 'lucide-react'
import { cn } from '@/lib/utils'

export function SecurityBadge({ label, className }: { label: string; className?: string }) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full border border-success/25 bg-success/10 px-2.5 py-1 font-mono text-[11px] font-medium tracking-wide text-success',
        className,
      )}
    >
      <ShieldCheck className="size-3.5" aria-hidden="true" />
      <span>
        Rummaina <span className="text-foreground/80">·</span> {label}
      </span>
    </span>
  )
}

export function EncryptionIndicator({ className }: { className?: string }) {
  return (
    <span
      className={cn('inline-flex items-center gap-2 font-mono text-[11px] text-muted-foreground', className)}
      title="Data in transit is protected with TLS 1.3; at rest with AES-256-GCM"
    >
      <span className="relative flex size-2">
        <span className="absolute inline-flex size-full animate-ping rounded-full bg-success opacity-60" />
        <span className="relative inline-flex size-2 rounded-full bg-success" />
      </span>
      E2E · TLS 1.3 · AES-256-GCM
    </span>
  )
}
