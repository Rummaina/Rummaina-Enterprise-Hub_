import { RummainaLogo } from '@/components/brand/rummaina-logo'
import { EncryptionIndicator, SecurityBadge } from '@/components/brand/security-badge'

export function SiteFooter() {
  return (
    <footer className="border-t border-border">
      <div className="mx-auto flex max-w-7xl flex-col gap-6 px-4 py-10 md:flex-row md:items-center md:justify-between md:px-6">
        <RummainaLogo />
        <div className="flex flex-wrap items-center gap-3">
          <SecurityBadge label="Zero Trust" />
          <SecurityBadge label="MFA Enforced" />
          <EncryptionIndicator />
        </div>
        <p className="text-sm text-muted-foreground">
          {'© '}
          {new Date().getFullYear()} Rummaina. All rights reserved.
        </p>
      </div>
    </footer>
  )
}
