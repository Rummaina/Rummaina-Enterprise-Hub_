'use client'

import { Activity, ShieldCheck } from 'lucide-react'
import { drift, formatNumber, useTicker } from '@/lib/simulation'

const checks = [
  'Device posture attested',
  'Identity verified (WebAuthn)',
  'Session bound to TLS channel',
  'Least-privilege policy applied',
]

export function HeroConsole() {
  const live = useTicker(
    { score: 98, rps: 24812, threats: 1204 },
    (p) => ({
      score: Math.round(drift(p.score, 2, 95, 100)),
      rps: Math.round(drift(p.rps, 1800, 18000, 32000)),
      threats: p.threats + Math.floor(Math.random() * 4),
    }),
    1600,
  )

  return (
    <div className="glass relative rounded-2xl p-5 md:p-6">
      <div className="flex items-center justify-between border-b border-border pb-4">
        <div className="flex items-center gap-2">
          <span className="size-2.5 rounded-full bg-destructive/70" />
          <span className="size-2.5 rounded-full bg-warning/70" />
          <span className="size-2.5 rounded-full bg-success/70" />
        </div>
        <span className="font-mono text-xs text-muted-foreground">rummaina://posture/live</span>
      </div>

      <div className="grid gap-4 pt-5 sm:grid-cols-[auto_1fr] sm:items-center">
        <div
          className="relative mx-auto grid size-36 place-items-center rounded-full"
          style={{
            background: `conic-gradient(var(--success) ${live.score * 3.6}deg, oklch(1 0 0 / 8%) 0deg)`,
          }}
          role="img"
          aria-label={`Security posture score ${live.score} out of 100`}
        >
          <div className="grid size-28 place-items-center rounded-full bg-background">
            <div className="text-center">
              <div className="font-mono text-3xl font-semibold">{live.score}</div>
              <div className="text-[11px] tracking-widest text-muted-foreground uppercase">Posture</div>
            </div>
          </div>
        </div>
        <ul className="flex flex-col gap-2.5">
          {checks.map((c) => (
            <li key={c} className="flex items-center gap-2.5 text-sm">
              <ShieldCheck className="size-4 shrink-0 text-success" aria-hidden="true" />
              {c}
            </li>
          ))}
        </ul>
      </div>

      <div className="mt-5 grid grid-cols-2 gap-3">
        <div className="rounded-xl border border-border bg-background/40 p-4">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Activity className="size-3.5 text-primary" aria-hidden="true" /> Requests / sec
          </div>
          <div className="mt-1 font-mono text-xl font-semibold tabular-nums" aria-live="off">
            {formatNumber(live.rps)}
          </div>
        </div>
        <div className="rounded-xl border border-border bg-background/40 p-4">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <ShieldCheck className="size-3.5 text-destructive" aria-hidden="true" /> Threats blocked
          </div>
          <div className="mt-1 font-mono text-xl font-semibold tabular-nums">{formatNumber(live.threats)}</div>
        </div>
      </div>
    </div>
  )
}
