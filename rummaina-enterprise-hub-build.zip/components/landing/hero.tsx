import Link from 'next/link'
import { ArrowRight, Fingerprint, Gauge, Lock } from 'lucide-react'
import { SecurityBadge } from '@/components/brand/security-badge'
import { buttonVariants } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import { HeroConsole } from './hero-console'

const stats = [
  { value: '99.99%', label: 'Uptime SLA' },
  { value: '<180ms', label: 'Global TTFB p95' },
  { value: '0', label: 'Trust assumed' },
  { value: '312', label: 'Edge PoPs' },
]

export function Hero() {
  return (
    <section className="relative overflow-hidden">
      <div className="grid-backdrop pointer-events-none absolute inset-0" aria-hidden="true" />
      <div className="relative mx-auto grid max-w-7xl gap-14 px-4 pt-20 pb-16 md:px-6 lg:grid-cols-[1.05fr_1fr] lg:items-center lg:pt-28">
        <div className="flex flex-col items-start gap-7">
          <SecurityBadge label="SOC 2 Type II · ISO 27001 aligned" />
          <h1 className="text-balance text-4xl font-semibold tracking-tight sm:text-5xl lg:text-6xl">
            <span className="block font-mono text-sm font-medium tracking-[0.3em] text-primary uppercase">
              Rummaina
            </span>
            <span className="mt-3 block">The zero-trust command center for the modern enterprise.</span>
          </h1>
          <p className="max-w-xl text-pretty text-lg leading-relaxed text-muted-foreground">
            Verify every request, encrypt every byte, and observe every node from one control plane. Rummaina
            Enterprise Hub unifies identity, edge delivery, and workflow automation with sub-second visibility.
          </p>
          <div className="flex flex-wrap items-center gap-3">
            <Link href="/dashboard" className={cn(buttonVariants({ size: 'lg' }), 'h-11 px-5 text-sm')}>
              Launch Control Center
              <ArrowRight data-icon="inline-end" aria-hidden="true" />
            </Link>
            <Link
              href="/login"
              className={cn(buttonVariants({ variant: 'outline', size: 'lg' }), 'h-11 px-5 text-sm')}
            >
              <Fingerprint data-icon="inline-start" aria-hidden="true" />
              Try MFA sign-in
            </Link>
          </div>
          <ul className="flex flex-wrap gap-x-6 gap-y-2 text-sm text-muted-foreground">
            <li className="flex items-center gap-2">
              <Lock className="size-4 text-success" aria-hidden="true" /> Hardened response headers
            </li>
            <li className="flex items-center gap-2">
              <Gauge className="size-4 text-primary" aria-hidden="true" /> Streamed, lazy-loaded panels
            </li>
          </ul>
        </div>
        <HeroConsole />
      </div>
      <div className="relative mx-auto max-w-7xl px-4 pb-20 md:px-6">
        <dl className="glass grid grid-cols-2 divide-border rounded-2xl md:grid-cols-4 md:divide-x">
          {stats.map((s) => (
            <div key={s.label} className="flex flex-col gap-1 p-6">
              <dt className="order-2 text-sm text-muted-foreground">{s.label}</dt>
              <dd className="order-1 font-mono text-2xl font-semibold tracking-tight md:text-3xl">{s.value}</dd>
            </div>
          ))}
        </dl>
      </div>
    </section>
  )
}
