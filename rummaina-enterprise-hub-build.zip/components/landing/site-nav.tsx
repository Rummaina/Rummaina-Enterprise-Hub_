import Link from 'next/link'
import { RummainaLogo } from '@/components/brand/rummaina-logo'
import { EncryptionIndicator } from '@/components/brand/security-badge'
import { buttonVariants } from '@/components/ui/button'
import { cn } from '@/lib/utils'

const links = [
  { href: '#security', label: 'Security' },
  { href: '#performance', label: 'Performance' },
  { href: '#control', label: 'Control Center' },
]

export function SiteNav() {
  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/60 backdrop-blur-xl">
      <nav aria-label="Primary" className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-6 px-4 md:px-6">
        <Link href="/" aria-label="Rummaina Enterprise Hub home" className="rounded-md">
          <RummainaLogo />
        </Link>
        <ul className="hidden items-center gap-1 md:flex">
          {links.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                className="rounded-md px-3 py-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
              >
                {l.label}
              </a>
            </li>
          ))}
        </ul>
        <div className="flex items-center gap-3">
          <EncryptionIndicator className="hidden lg:inline-flex" />
          <Link href="/login" className={cn(buttonVariants({ variant: 'ghost', size: 'lg' }), 'hidden sm:inline-flex')}>
            Sign in
          </Link>
          <Link href="/dashboard" className={cn(buttonVariants({ size: 'lg' }), 'px-4')}>
            Open Console
          </Link>
        </div>
      </nav>
    </header>
  )
}
