import Link from 'next/link'
import { ArrowRight, BarChart3, Cpu, Workflow } from 'lucide-react'
import { RummainaMark } from '@/components/brand/rummaina-logo'
import { SecurityBadge } from '@/components/brand/security-badge'
import { buttonVariants } from '@/components/ui/button'
import { cn } from '@/lib/utils'

const features = [
  { icon: BarChart3, label: 'Real-time analytics & traffic graphs' },
  { icon: Cpu, label: 'Per-node server health & capacity' },
  { icon: Workflow, label: 'Live workflow automation logs' },
]

export function ControlCta() {
  return (
    <section id="control" className="scroll-mt-20 border-t border-border">
      <div className="mx-auto max-w-7xl px-4 py-24 md:px-6">
        <div className="glass relative overflow-hidden rounded-3xl p-8 md:p-12">
          <div className="grid-backdrop pointer-events-none absolute inset-0 opacity-60" aria-hidden="true" />
          <div className="relative grid gap-10 md:grid-cols-[1.2fr_1fr] md:items-center">
            <div className="flex flex-col items-start gap-5">
              <SecurityBadge label="Admin Control Center" />
              <h2 className="text-balance text-3xl font-semibold tracking-tight md:text-4xl">
                One console to operate your entire estate.
              </h2>
              <ul className="flex flex-col gap-3">
                {features.map(({ icon: Icon, label }) => (
                  <li key={label} className="flex items-center gap-3 text-muted-foreground">
                    <Icon className="size-5 text-primary" aria-hidden="true" />
                    {label}
                  </li>
                ))}
              </ul>
              <Link href="/dashboard" className={cn(buttonVariants({ size: 'lg' }), 'mt-2 h-11 px-5 text-sm')}>
                Enter Control Center
                <ArrowRight data-icon="inline-end" aria-hidden="true" />
              </Link>
            </div>
            <div className="hidden justify-center md:flex" aria-hidden="true">
              <RummainaMark className="size-56 opacity-90 drop-shadow-[0_0_40px_var(--primary)]" />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
