import { LoadBalancerSim } from '@/components/performance/load-balancer-sim'
import { EdgeCacheSim } from '@/components/performance/edge-cache-sim'

export function PerformanceSection() {
  return (
    <section id="performance" className="scroll-mt-20 border-t border-border">
      <div className="mx-auto max-w-7xl px-4 py-24 md:px-6">
        <div className="flex max-w-2xl flex-col gap-4">
          <span className="font-mono text-xs tracking-[0.3em] text-primary uppercase">Performance</span>
          <h2 className="text-balance text-3xl font-semibold tracking-tight md:text-4xl">
            Served from the edge. Balanced across the globe.
          </h2>
          <p className="text-pretty text-muted-foreground">
            Static shells stream instantly while heavy panels hydrate on demand. Try the interactive simulations
            below.
          </p>
        </div>
        <div className="mt-12 grid gap-4 lg:grid-cols-2">
          <LoadBalancerSim />
          <EdgeCacheSim />
        </div>
      </div>
    </section>
  )
}
