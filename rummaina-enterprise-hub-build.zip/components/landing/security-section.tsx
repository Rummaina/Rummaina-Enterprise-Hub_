import { Code2, Fingerprint, KeyRound, Network, ShieldAlert, Database } from 'lucide-react'
import { SecurityBadge } from '@/components/brand/security-badge'

const pillars = [
  {
    icon: Network,
    title: 'Zero-trust access',
    body: 'Every request is authenticated, authorized, and continuously re-evaluated against identity, device, and context.',
  },
  {
    icon: Fingerprint,
    title: 'Multi-factor by default',
    body: 'Phishing-resistant factors — WebAuthn passkeys and TOTP — gate privileged actions with step-up challenges.',
  },
  {
    icon: KeyRound,
    title: 'Encryption everywhere',
    body: 'TLS 1.3 in transit, AES-256-GCM at rest, with envelope keys rotated automatically through a managed KMS.',
  },
  {
    icon: Code2,
    title: 'XSS containment',
    body: 'React output escaping, strict Content-Security-Policy, and nosniff headers keep injected scripts inert.',
  },
  {
    icon: ShieldAlert,
    title: 'CSRF defense',
    body: 'SameSite cookies, origin verification on Server Actions, and per-session tokens for state-changing calls.',
  },
  {
    icon: Database,
    title: 'Injection-proof data layer',
    body: 'Parameterized queries only, schema-validated inputs, and least-privilege database roles per service.',
  },
]

export function SecuritySection() {
  return (
    <section id="security" className="scroll-mt-20 border-t border-border">
      <div className="mx-auto max-w-7xl px-4 py-24 md:px-6">
        <div className="flex max-w-2xl flex-col gap-4">
          <SecurityBadge label="Zero-Trust Architecture" className="self-start" />
          <h2 className="text-balance text-3xl font-semibold tracking-tight md:text-4xl">
            Security architecture that assumes breach — and contains it.
          </h2>
          <p className="text-pretty text-muted-foreground">
            Rummaina layers defenses so a single failure never becomes an incident. Each control is observable from
            the Security Health dashboard in real time.
          </p>
        </div>
        <ul className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {pillars.map(({ icon: Icon, title, body }) => (
            <li key={title} className="glass glass-hover flex flex-col gap-3 rounded-2xl p-6">
              <span className="grid size-10 place-items-center rounded-lg border border-primary/20 bg-primary/10 text-primary">
                <Icon className="size-5" aria-hidden="true" />
              </span>
              <h3 className="text-lg font-medium">{title}</h3>
              <p className="text-sm leading-relaxed text-muted-foreground">{body}</p>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
