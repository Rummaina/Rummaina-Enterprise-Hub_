import type { Metadata } from 'next'
import { DashboardSidebar } from '@/components/dashboard/dashboard-sidebar'
import { DashboardHeader } from '@/components/dashboard/dashboard-header'
import { MetricCards } from '@/components/dashboard/metric-cards'
import { LazyRegionLatencyChart, LazyTrafficChart } from '@/components/dashboard/lazy-panels'
import { SecurityHealth } from '@/components/dashboard/security-health'
import { ServerHealth } from '@/components/dashboard/server-health'
import { WorkflowLogs } from '@/components/dashboard/workflow-logs'
import { LoadBalancerSim } from '@/components/performance/load-balancer-sim'
import { EdgeCacheSim } from '@/components/performance/edge-cache-sim'

export const metadata: Metadata = {
  title: 'Control Center',
  description: 'Real-time system metrics, security posture, server health, and workflow automation.',
  robots: { index: false, follow: false },
}

export default function DashboardPage() {
  return (
    <div className="flex min-h-dvh">
      <DashboardSidebar />
      <div className="flex min-w-0 flex-1 flex-col">
        <DashboardHeader />
        <main className="flex flex-col gap-4 p-4 md:p-6">
          <MetricCards />

          <div id="analytics" className="grid scroll-mt-20 gap-4 xl:grid-cols-[2fr_1fr]">
            <LazyTrafficChart />
            <LazyRegionLatencyChart />
          </div>

          <div className="grid gap-4 xl:grid-cols-[1fr_1.4fr]">
            <div id="security" className="scroll-mt-20">
              <SecurityHealth />
            </div>
            <div id="servers" className="scroll-mt-20">
              <ServerHealth />
            </div>
          </div>

          <div id="traffic" className="grid scroll-mt-20 gap-4 lg:grid-cols-2">
            <LoadBalancerSim />
            <EdgeCacheSim />
          </div>

          <div id="workflows" className="scroll-mt-20">
            <WorkflowLogs />
          </div>
        </main>
      </div>
    </div>
  )
}
