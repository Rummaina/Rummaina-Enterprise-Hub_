import { SiteNav } from '@/components/landing/site-nav'
import { Hero } from '@/components/landing/hero'
import { SecuritySection } from '@/components/landing/security-section'
import { PerformanceSection } from '@/components/landing/performance-section'
import { ControlCta } from '@/components/landing/control-cta'
import { SiteFooter } from '@/components/landing/site-footer'

export default function HomePage() {
  return (
    <>
      <SiteNav />
      <main>
        <Hero />
        <SecuritySection />
        <PerformanceSection />
        <ControlCta />
      </main>
      <SiteFooter />
    </>
  )
}
