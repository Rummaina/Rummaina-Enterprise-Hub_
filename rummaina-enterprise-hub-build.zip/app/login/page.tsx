import type { Metadata } from 'next'
import Link from 'next/link'
import { RummainaLogo } from '@/components/brand/rummaina-logo'
import { MfaFlow } from '@/components/auth/mfa-flow'

export const metadata: Metadata = {
  title: 'Sign in',
  description: 'Multi-factor sign-in to Rummaina Enterprise Hub.',
}

export default function LoginPage() {
  return (
    <main className="relative flex min-h-dvh flex-col items-center justify-center gap-8 px-4 py-12">
      <div className="grid-backdrop pointer-events-none absolute inset-0" aria-hidden="true" />
      <Link href="/" aria-label="Back to Rummaina home" className="relative">
        <RummainaLogo />
      </Link>
      <div className="relative flex w-full justify-center">
        <MfaFlow />
      </div>
    </main>
  )
}
