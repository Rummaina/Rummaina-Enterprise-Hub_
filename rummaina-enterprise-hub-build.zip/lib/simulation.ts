'use client'

import { useEffect, useRef, useState } from 'react'

/** Deterministic PRNG so server and client render identical initial telemetry. */
export function seeded(seed: number) {
  let s = seed >>> 0
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0
    return s / 4294967296
  }
}

export const clamp = (v: number, min: number, max: number) => Math.min(max, Math.max(min, v))

export function drift(value: number, spread: number, min: number, max: number) {
  return clamp(value + (Math.random() - 0.5) * spread, min, max)
}

/**
 * Runs `tick` on an interval after mount. Initial state stays deterministic for hydration,
 * and the timer pauses while the tab is hidden to avoid burning CPU in background tabs.
 */
export function useTicker<T>(initial: T, tick: (prev: T) => T, intervalMs: number) {
  const [state, setState] = useState(initial)
  const tickRef = useRef(tick)
  tickRef.current = tick

  useEffect(() => {
    let id: ReturnType<typeof setInterval> | undefined
    const start = () => {
      if (id === undefined) id = setInterval(() => setState((p) => tickRef.current(p)), intervalMs)
    }
    const stop = () => {
      if (id !== undefined) clearInterval(id)
      id = undefined
    }
    const onVisibility = () => (document.hidden ? stop() : start())
    start()
    document.addEventListener('visibilitychange', onVisibility)
    return () => {
      stop()
      document.removeEventListener('visibilitychange', onVisibility)
    }
  }, [intervalMs])

  return state
}

export type TrafficPoint = { t: string; requests: number; blocked: number; latency: number }

export function initialTraffic(points = 24): TrafficPoint[] {
  const rand = seeded(42)
  return Array.from({ length: points }, (_, i) => ({
    t: `${String(i).padStart(2, '0')}:00`,
    requests: Math.round(18000 + Math.sin(i / 3) * 6000 + rand() * 3000),
    blocked: Math.round(300 + rand() * 450),
    latency: Math.round(38 + rand() * 22),
  }))
}

export type ServerNode = {
  id: string
  region: string
  cpu: number
  memory: number
  connections: number
  status: 'healthy' | 'degraded' | 'draining'
}

export const initialNodes: ServerNode[] = [
  { id: 'rmn-edge-iad1', region: 'US East · Virginia', cpu: 42, memory: 58, connections: 1840, status: 'healthy' },
  { id: 'rmn-edge-sfo1', region: 'US West · San Francisco', cpu: 37, memory: 51, connections: 1520, status: 'healthy' },
  { id: 'rmn-edge-fra1', region: 'EU Central · Frankfurt', cpu: 61, memory: 66, connections: 2110, status: 'healthy' },
  { id: 'rmn-edge-sin1', region: 'APAC · Singapore', cpu: 74, memory: 71, connections: 2380, status: 'degraded' },
  { id: 'rmn-edge-gru1', region: 'LATAM · São Paulo', cpu: 29, memory: 44, connections: 980, status: 'healthy' },
]

export function tickNodes(nodes: ServerNode[]): ServerNode[] {
  return nodes.map((n) => {
    const cpu = Math.round(drift(n.cpu, 10, 12, 96))
    return {
      ...n,
      cpu,
      memory: Math.round(drift(n.memory, 6, 25, 92)),
      connections: Math.round(drift(n.connections, 220, 400, 3200)),
      status: cpu > 85 ? 'draining' : cpu > 70 ? 'degraded' : 'healthy',
    }
  })
}

export const formatNumber = (n: number) => new Intl.NumberFormat('en-US').format(n)
export const formatCompact = (n: number) =>
  new Intl.NumberFormat('en-US', { notation: 'compact', maximumFractionDigits: 1 }).format(n)
